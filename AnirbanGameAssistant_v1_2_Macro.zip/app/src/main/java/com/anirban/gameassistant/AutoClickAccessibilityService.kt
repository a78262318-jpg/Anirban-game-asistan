package com.anirban.gameassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoClickAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private val task = object : Runnable {
        override fun run() {
            if (!running) return
            val dm = resources.displayMetrics
            val path = Path().apply { moveTo(dm.widthPixels / 2f, dm.heightPixels / 2f) }
            val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build()
            dispatchGesture(gesture, null, null)
            handler.postDelayed(this, intervalMs)
        }
    }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopTapping() }
    fun startTapping() { if (!running) { running = true; handler.post(task) } }

    fun stopTapping() { running = false; handler.removeCallbacks(task) }

    fun playMacro(points: List<MacroPoint>, padWidth: Float, padHeight: Float, repeats: Int) {
        if (points.isEmpty() || padWidth <= 0f || padHeight <= 0f) return
        stopTapping()
        var round = 0
        fun playRound() {
            if (round >= repeats) return
            round++
            val dm = resources.displayMetrics
            val scaleX = dm.widthPixels / padWidth
            val scaleY = dm.heightPixels / padHeight
            val builder = GestureDescription.Builder()
            val path = Path()
            points.forEachIndexed { index, point ->
                val x = point.x * padWidth * scaleX
                val y = point.y * padHeight * scaleY
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val duration = (points.last().time - points.first().time).coerceAtLeast(120L)
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            dispatchGesture(builder.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    handler.postDelayed({ playRound() }, 250L)
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    handler.postDelayed({ playRound() }, 250L)
                }
            }, handler)
        }
        playRound()
    }
    override fun onDestroy() { stopTapping(); if (instance === this) instance = null; super.onDestroy() }
    companion object {
        var instance: AutoClickAccessibilityService? = null
        @Volatile var intervalMs: Long = 500L
    }
}
