package com.anirban.gameassistant

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private var tapping = false
    private var macroRepeat = false
    private val channelId = "aga_controls"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Floating assistant", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("Game Assistant running").setContentText("Tap the floating dot to open controls").setSmallIcon(android.R.drawable.ic_media_play).build()
        else Notification.Builder(this).setContentTitle("Game Assistant running").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(7, n)
        showBubble()
    }
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
    private fun showBubble() {
        val b = TextView(this).apply {
            text = "●"; textSize = 30f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(80,255,130)); setBackgroundColor(Color.rgb(20,30,25))
            setOnClickListener { if (panel == null) showPanel() else closePanel() }
        }
        bubble = b
        val p = params(64,64).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 260 }
        try { wm.addView(b,p) } catch (_: Exception) {}
    }
    private fun closePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }
    private fun showPanel() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(Color.rgb(15,22,20)) }
        fun label(s: String, size: Float = 14f) { box.addView(TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(4,5,4,5) }) }
        fun action(s: String, f: () -> Unit) { box.addView(Button(this).apply { text=s; setOnClickListener { f() } }) }
        label("ANIRBAN GAME ASSISTANT",19f)
        label("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level",-1) ?: -1
        val scale = battery?.getIntExtra("scale",100) ?: 100
        val pct = if (level >= 0 && scale > 0) level*100/scale else -1
        val status = battery?.getIntExtra("status",-1) ?: -1
        label("Battery: $pct% • ${if (status == 2) "Charging" else "Not charging"}")
        label("Time: ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())}")
        action(if (tapping) "AUTO TAP: ON — STOP" else "AUTO TAP: OFF — START") {
            val svc = AutoClickAccessibilityService.instance
            if (svc == null) {
                Toast.makeText(this,"Enable this app in Accessibility settings first",Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else { tapping = !tapping; if (tapping) svc.startTapping() else svc.stopTapping(); closePanel(); showPanel() }
        }
        action("Tap interval: switch 500 ms / 1000 ms") {
            AutoClickAccessibilityService.intervalMs = if (AutoClickAccessibilityService.intervalMs == 500L) 1000L else 500L
            Toast.makeText(this,"Interval: ${AutoClickAccessibilityService.intervalMs} ms",Toast.LENGTH_SHORT).show()
        }
        action(if (macroRepeat) "MACRO REPEAT: ON" else "MACRO REPEAT: OFF") {
            macroRepeat = !macroRepeat
            Toast.makeText(this,"Repeat preference toggled. Gesture recording/playback is not implemented in this starter version.",Toast.LENGTH_LONG).show()
            closePanel(); showPanel()
        }
        action("Open Home screen") { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        action("Close panel") { closePanel() }
        panel = box
        val p = params(300,WindowManager.LayoutParams.WRAP_CONTENT).apply { gravity=Gravity.CENTER; flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        try { wm.addView(box,p) } catch (_: Exception) { panel=null }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { closePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; AutoClickAccessibilityService.instance?.stopTapping(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
